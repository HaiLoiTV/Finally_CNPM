﻿using DatabaseProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddNewProduct
{
    public partial class ItemList : Form
    {
        DBAccess objDBA = new DBAccess();
        
        String ID;
        public ItemList()
        {
            InitializeComponent();
        }

        private void ItemList_Load(object sender, EventArgs e)
        {
            display();
        }
        private void display()
        {
            DataTable dtBook = new DataTable();
            string query = "Select * from Sach";
            objDBA.readDatathroughAdapter(query, dtBook);
            dataGridItem.DataSource = dtBook;
            objDBA.closeConn();
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string cmd = "Delete from Sach where MaSach=(Select MaSach from Sach where MaSach=@maSach and MaSach not in (Select MaSach from HoaDon_Sach))";
            SqlCommand delete = new SqlCommand(cmd);
            delete.Parameters.AddWithValue("@maSach", ID);
            int row = objDBA.executeQuery(delete);
            if(row==1)
            {
                MessageBox.Show("Xóa dữ liệu thành công");
            }
            else
            {
                MessageBox.Show("Không thể xóa dữ liệu này");
            }
            clear();
            display();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Equals("") || txtAuthor.Text.Equals("") || txtGenre.Text.Equals("") || txtPublisher.Text.Equals("") || txtCountry.Text.Equals("") || txtQuantity.Text.Equals("") || txtPrice.Text.Equals(""))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
            }
            else {
                string query = "Select TOP 1 MaSach from Sach order by MaSach desc";
                DataTable dtMaSach = new DataTable();
                objDBA.readDatathroughAdapter(query, dtMaSach);
                string maSach = dtMaSach.Rows[0]["MaSach"].ToString();
                int id = Int32.Parse(maSach.Substring(2));
                id += 1;
                maSach = maSach.Substring(0, 2);
                if (id < 10)
                {
                    maSach = maSach + "0" + id.ToString();
                }
                else
                {
                    maSach += id.ToString();
                }
                string cmd = "insert into SACH(MaSach,TenSach,TacGia,TheLoai,NXB,QuocGia,SL,GiaBan) values(@maSach,@tenSach,@tacGia,@theLoai,@NXB,@quocGia,@soLuong,@donGia)";
                SqlCommand insert = new SqlCommand(cmd);
                insert.Parameters.AddWithValue("@maSach", maSach);
                insert.Parameters.AddWithValue("@tenSach", txtName.Text);
                insert.Parameters.AddWithValue("@tacGia", txtAuthor.Text);
                insert.Parameters.AddWithValue("@theLoai", txtGenre.Text);
                insert.Parameters.AddWithValue("@NXB", txtPublisher.Text);
                insert.Parameters.AddWithValue("@quocGia", txtCountry.Text);
                insert.Parameters.AddWithValue("@soLuong", txtQuantity.Text);
                insert.Parameters.AddWithValue("@donGia", txtPrice.Text);
                int row = objDBA.executeQuery(insert);
                if (row==1)
                {
                    MessageBox.Show("Thêm dữ liệu thành công");
                }
                else
                {
                    MessageBox.Show("Có lỗi xảy ra, vui lòng thử lại");
                }
                clear();
                display();
            }
        }
        private void clear()
        {
            txtName.Text = "";
            txtAuthor.Text = "";
            txtGenre.Text = "";
            txtPublisher.Text = "";
            txtCountry.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
        }
        private void btnChange_Click(object sender, EventArgs e)
        {
            string cmd = "update Sach set TenSach=@tenSach,TacGia=@tacGia,TheLoai=@theLoai,NXB=@NXB,QuocGia=@quocGia,SL=@soLuong,GiaBan=@donGia where MaSach='" + ID + "'";
            SqlCommand update = new SqlCommand(cmd);
            update.Parameters.AddWithValue("@tenSach", txtName.Text);
            update.Parameters.AddWithValue("@tacGia", txtAuthor.Text);
            update.Parameters.AddWithValue("@theLoai", txtGenre.Text);
            update.Parameters.AddWithValue("@NXB", txtPublisher.Text);
            update.Parameters.AddWithValue("@quocGia", txtCountry.Text);
            update.Parameters.AddWithValue("@soLuong", txtQuantity.Text);
            update.Parameters.AddWithValue("@donGia", txtPrice.Text);
            objDBA.executeQuery(update);
            MessageBox.Show("Sửa dữ liệu thành công");
            display();
        }
        private void dataGridItem_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = dataGridItem.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dataGridItem.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtAuthor.Text = dataGridItem.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtGenre.Text = dataGridItem.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtPublisher.Text = dataGridItem.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtCountry.Text = dataGridItem.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtQuantity.Text = dataGridItem.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtPrice.Text = dataGridItem.Rows[e.RowIndex].Cells[7].Value.ToString();
        }
        private void txtBookSearch_TextChanged(object sender, EventArgs e)
        {
            DataTable dtBook = new DataTable();
            string query = "Select * from Sach  where TenSach like '%" + txtBookSearch.Text + "%'";
            objDBA.readDatathroughAdapter(query, dtBook);
            dataGridItem.DataSource = dtBook;
            objDBA.closeConn();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}
