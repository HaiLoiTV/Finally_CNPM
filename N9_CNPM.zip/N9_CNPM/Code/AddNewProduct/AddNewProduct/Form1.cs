﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AddNewProduct
{
    public partial class Form1 : Form
    {
        SqlConnection cnn;
        public Form1()
        {
            InitializeComponent();
            cnn = new SqlConnection(@"Data Source=DESKTOP-AJM515U\THANHLOI;Initial Catalog=QLNhaSach;User ID=sa;Password=0936659324");
            cnn.Open();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        public void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            String query = "";
            List<String> TK = new List<String>();
            List<String> MK = new List<String>();
            query = "Select TKNV,MKNV from TK_NhanVien";
            command = new SqlCommand(query, cnn);
            dataReader = command.ExecuteReader();
            while (dataReader.Read())
            {
                TK.Add((string)dataReader.GetValue(0));
                MK.Add((string)dataReader.GetValue(1));
            }
            //Kiểm tra tài khoản hoặc mật khẩu bỏ trống
            if (txtTK.Text == "" || txtMK.Text == "")
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu không hợp lệ");
                txtTK.Text = "";
                txtMK.Text = "";
                txtTK.Focus();
                cmbChucVu.Text = "";
                dataReader.Close();
                command.Dispose();
            }
            //Kiểm tra chọn chức vụ
            else if (cmbChucVu.Text == "")
            {
                MessageBox.Show("Vui lòng chọn chức vụ");
                dataReader.Close();
                command.Dispose();
            }
            //Chọn chức vụ không phù hợp với tài khoản
            else if (cmbChucVu.SelectedItem.Equals("Thu ngân"))
            {
                if (txtTK.ToString().Contains("NV"))
                {
                    Boolean check = false;
                    for (int i = 0; i < TK.Count(); i++)
                    {
                        if (txtTK.Text == TK[i] && txtMK.Text == MK[i])
                        {
                            check = true;
                            dataReader.Close();
                            command.Dispose();
                            MessageBox.Show("Đăng nhập thành công");
                            this.Hide();
                            Form2 form2 = new Form2(txtTK.Text);
                            form2.ShowDialog();
                        }
                    }
                    if (check == false)
                    {
                        MessageBox.Show("Đăng nhập không thành công");
                        txtTK.Text = "";
                        txtMK.Text = "";
                        cmbChucVu.Text = "";
                        txtTK.Focus();
                        dataReader.Close();
                        command.Dispose();
                    }
                }
                else
                {
                    MessageBox.Show("Chức vụ bạn chọn không phù với với tài khoản");
                    txtTK.Text = "";
                    txtMK.Text = "";
                    cmbChucVu.Text = "";
                    txtTK.Focus();
                    dataReader.Close();
                    command.Dispose();
                }
            }
            else if (cmbChucVu.SelectedItem.Equals("Quản lý"))
            {
                if (txtTK.ToString().Contains("QL"))
                {
                    Boolean checkQL = false;
                    for (int i = 0; i < TK.Count(); i++)
                    {
                        if (txtTK.Text == TK[i] && txtMK.Text == MK[i])
                        {
                            checkQL = true;
                            dataReader.Close();
                            command.Dispose();
                            MessageBox.Show("Đăng nhập thành công");
                            this.Hide();
                            Form4 form4 = new Form4();
                            form4.ShowDialog();
                        }
                    }
                    if (checkQL == false)
                    {
                        MessageBox.Show("Đăng nhập không thành công");
                        txtTK.Text = "";
                        txtMK.Text = "";
                        cmbChucVu.Text = "";
                        txtTK.Focus();
                        dataReader.Close();
                        command.Dispose();
                    }
                }
                else
                {
                    MessageBox.Show("Đăng nhập không thành công");
                    txtTK.Text = "";
                    txtMK.Text = "";
                    cmbChucVu.Text = "";
                    txtTK.Focus();
                    dataReader.Close();
                    command.Dispose();
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtTK_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
