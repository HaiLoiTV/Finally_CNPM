﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AddNewProduct
{
    public partial class Form3 : Form
    {
        SqlConnection cnn;
        double money = 0;
        String TK;
        List<SLSB> DanhSachSLSB = new List<SLSB>();
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(string taikhoan):this()
        {
            cnn = new SqlConnection(@"Data Source=DESKTOP-AJM515U\THANHLOI;Initial Catalog=QLNhaSach;User ID=sa;Password=0936659324");
            cnn.Open();
            TK = taikhoan;
        }
        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            String query1 = "";
            query1 = "Select TenSach,GiaBan from Sach where MaSach = @masach";
            command = new SqlCommand(query1, cnn);
            //Truyền tham số mã sách vào query1 tương ứng với mỗi mã sách được quét
            command.Parameters.AddWithValue("masach", txtSanPham.Text);
            dataReader = command.ExecuteReader();
            //Thể hiện lên ViewItem
            ListViewItem lv = new ListViewItem(txtSanPham.Text);
            int sl = Convert.ToInt32(txtSoLuong.Text);
            //Thêm mã và sl sách đã bán vào list 
            DanhSachSLSB.Add(new SLSB(txtSanPham.Text, sl));
            //Đọc dữ liệu trả về khi chạy câu lệnh query1
            while (dataReader.Read())
            {
                lv.SubItems.Add((String)dataReader.GetValue(0));
                lv.SubItems.Add(txtSoLuong.Text);
                double dongia = Convert.ToDouble(dataReader.GetValue(1));
                //Tổng tiền được cập nhật
                money = money + dongia * sl;
                String temp = dongia.ToString();
                lv.SubItems.Add(temp);
                lvSanPham.Items.Add(lv);
            }
            dataReader.Close();
            command.Dispose();
            //Show tổng tiền
            txtMoney.Text = money.ToString();
            SqlCommand command1;
            SqlDataReader dataReader1;
            String query2 = "";
            query2 = "Update Sach set SL=SL-@sl where MaSach = @ms";
            command1 = new SqlCommand(query2, cnn);
            //Cập nhật số lượng trong database
            command1.Parameters.AddWithValue("ms", txtSanPham.Text);
            command1.Parameters.AddWithValue("sl", sl);
            dataReader1 = command1.ExecuteReader();
            dataReader1.Close();
            command1.Dispose();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //khi nhân viên chọn sản phẩm đang có trong listView
            if (lvSanPham.SelectedItems.Count > 0)
            {
                //Lấy dữ liệu số lượng và đơn giá sản phẩm bị loại bỏ 
                //Để trừ vào tổng tiền
                ListViewItem temp = lvSanPham.SelectedItems[0];
                int sl = Convert.ToInt32(temp.SubItems[2].Text);
                double dongia = Convert.ToDouble(temp.SubItems[3].Text);
                money = money - (sl * dongia);
                txtMoney.Text = money.ToString();
                //Xóa mã sách và sl sách mà khách hàng yêu cầu bỏ
                int index = -1; //Vị trí sách bị xóa
                for(int i = 0; i<DanhSachSLSB.Count(); i++)
                {
                    if(DanhSachSLSB[i].MaSach == temp.SubItems[0].Text && DanhSachSLSB[i].soluong == sl)
                    {
                        index = i;
                        break;
                    }
                }
                DanhSachSLSB.RemoveAt(index);
                //Xóa bỏ sản phẩm mà khách yêu cầu
                lvSanPham.Items.Remove(lvSanPham.SelectedItems[0]);
                SqlCommand command1;
                SqlDataReader dataReader1;
                String query2 = "";
                query2 = "Update Sach set SL=SL+@sl where MaSach = @ms";
                command1 = new SqlCommand(query2, cnn);
                //Cập nhật số lượng sách trong database
                command1.Parameters.AddWithValue("ms", txtSanPham.Text);
                command1.Parameters.AddWithValue("sl", sl);
                dataReader1 = command1.ExecuteReader();
                dataReader1.Close();
                command1.Dispose();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            
            //Lấy ngày lập hóa đơn
            String nowaday = DateTime.Now.ToString();
            //Cập nhật dữ liệu vào db HoaDon và HoaDon_Sach
            SqlCommand cmd;
            SqlDataReader data;
            String query = "Select top 1 MaHD,MaKH from HoaDon order by MaHD desc";
            cmd = new SqlCommand(query, cnn);
            String HD = "";
            String KH = "";
            data = cmd.ExecuteReader();
            while (data.Read())
            {
                HD = data.GetValue(0).ToString();
                HD = HD.Substring(2);
                KH = data.GetValue(1).ToString();
                KH = KH.Substring(2);
            }
            data.Close();
            cmd.Dispose();
            int masoHD = Convert.ToInt32(HD);
            int masoKH = Convert.ToInt32(KH);
            masoHD = masoHD + 1;
            masoKH = masoKH + 1;
            if (masoHD < 10)
            {
                HD = "HD0" + masoHD.ToString();
            }
            else
            {

                HD = "HD" + masoHD.ToString();
            }
            if(masoKH < 10)
            {
                KH = "KH0" + masoKH.ToString();
            }
            else
            {
                KH = "KH" + masoKH.ToString();
            }
            //Thêm khách hàng vào cơ sở dữ liệu
            SqlCommand cmd_KH;
            String query_InsertKH = "Insert into KhachHang values(@makh,@ten,@sdt,@email)";
            cmd_KH = new SqlCommand(query_InsertKH, cnn);
            cmd_KH.Parameters.AddWithValue("makh", KH);
            cmd_KH.Parameters.AddWithValue("ten", txtTenKH.Text);
            cmd_KH.Parameters.AddWithValue("sdt", txtSDT.Text);
            cmd_KH.Parameters.AddWithValue("email", txtEmail.Text);
            cmd_KH.ExecuteNonQuery();
            cmd_KH.Dispose();
            //Thêm dữ liệu vào db HoaDon
            SqlCommand cmd1;
            String sql = "Insert into HoaDon values(@mahd,@tongtien,@ngaylap,@makh,@manv)";
            cmd1 = new SqlCommand(sql, cnn);
            cmd1.Parameters.AddWithValue("mahd", HD);
            cmd1.Parameters.AddWithValue("tongtien", txtMoney.Text);
            cmd1.Parameters.AddWithValue("ngaylap", nowaday);
            cmd1.Parameters.AddWithValue("makh", KH);
            cmd1.Parameters.AddWithValue("manv", TK);
            cmd1.ExecuteNonQuery();
            cmd1.Dispose();
            //Thêm dữ liệu vào db HoaDon_Sach
            for (int i = 0; i < DanhSachSLSB.Count(); i++)
            {
                SqlCommand cmd2;
                String query_insert = "Insert into HoaDon_Sach values(@hd,@sach,@sl)";
                cmd2 = new SqlCommand(query_insert, cnn);
                cmd2.Parameters.AddWithValue("hd", HD);
                cmd2.Parameters.AddWithValue("sach", DanhSachSLSB[i].MaSach);
                cmd2.Parameters.AddWithValue("sl", DanhSachSLSB[i].soluong);
                cmd2.ExecuteNonQuery();
                cmd2.Dispose();
            }
            //Lấy tên và giá bán của sách từ database
            //Lấy số lượng và mã sách từ list DanhSachSLSB
            String query2 = "", hoadon = "------------------------------Nhà sách Hai Lợi" +
                "------------------------------\nHóa đơn\nMã HD: "
                + HD + "\n" + "Mã KH: " + KH + "\n";
            query2 = "select TenSach,GiaBan from Sach where MaSach = @masach";
            for (int i=0; i < DanhSachSLSB.Count(); i++)
            {
                SqlDataReader dataReader2;
                SqlCommand command2;
                command2 = new SqlCommand(query2, cnn);
                command2.Parameters.AddWithValue("masach", DanhSachSLSB[i].MaSach);
                dataReader2 = command2.ExecuteReader();
                while (dataReader2.Read())
                {
                    hoadon = hoadon + DanhSachSLSB[i].MaSach + " - " + dataReader2.GetValue(0).ToString() +
                        " - " + DanhSachSLSB[i].soluong + " - " + dataReader2.GetValue(1).ToString()
                        + "\n";
                }
                dataReader2.Close();
                command2.Dispose();
            }
            hoadon = hoadon + "Ngày lập: " + nowaday + "\n";
            hoadon = hoadon + "\t\t\tTổng tiền: " + txtMoney.Text + "\n" + "Mã nhân viên: " + TK +
                "\nChúc quý khách một ngày vui vẻ";
            MessageBox.Show(hoadon);

        }

        private void txtTienThua_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtTienNhap_TextChanged(object sender, EventArgs e)
        {
            double tienNhap = Convert.ToDouble(txtTienNhap.Text);
            double tongTien = Convert.ToDouble(txtMoney.Text);
            double tienThua = tienNhap - tongTien;
            if (tienThua >= 0)
            {
                txtTienThua.Text = tienThua.ToString();
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }
    }
    public class SLSB
    {
        public String MaSach;
        public int soluong;
        public SLSB()
        {
            MaSach = "";
            soluong = 0;
        }
        public SLSB(String MaSach, int soluong)
        {
            this.MaSach = MaSach;
            this.soluong = soluong;
        }
    }
}
