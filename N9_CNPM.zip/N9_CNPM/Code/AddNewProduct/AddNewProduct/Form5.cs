﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AddNewProduct
{
    public partial class Form5 : Form
    {
        SqlConnection cnn;
        public Form5()
        {
            InitializeComponent();
            cnn = new SqlConnection(@"Data Source=DESKTOP-AJM515U\THANHLOI;Initial Catalog=QLNhaSach;User ID=sa;Password=0936659324");
            cnn.Open();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            lstThongke.Items.Clear();
            if (txtMonth.Text.Equals(""))
            {
                MessageBox.Show("Vui lòng chọn tháng muốn thống kê");
            }
            else
            {
                SqlCommand command;
                SqlDataReader dataReader;
                String query1 = "";
                query1 = "Select * from HoaDon where month(NgayLap) = @month";
                command = new SqlCommand(query1, cnn);
                command.Parameters.AddWithValue("month", txtMonth.Text);
                dataReader = command.ExecuteReader();
                String ThongKe = "";
                double Doanhthu = 0;
                lstThongke.Items.Add("Tháng " + txtMonth.Text);
                while (dataReader.Read())
                {
                    ThongKe = dataReader.GetValue(0).ToString() + " - " +
                        dataReader.GetValue(1).ToString() + " - " +
                        dataReader.GetValue(2).ToString() + " - " +
                        dataReader.GetValue(3).ToString() + " - " +
                        dataReader.GetValue(4).ToString();
                    Doanhthu = Doanhthu + Convert.ToDouble(dataReader.GetValue(1).ToString());
                    lstThongke.Items.Add(ThongKe);
                }
                lstThongke.Items.Add("Tổng doanh thu: " + Doanhthu.ToString() + " VND");
                dataReader.Close();
                command.Dispose();
                lstChitiet.Items.Clear();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Close();
        }

        private void lstThongke_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String temp = lstThongke.SelectedItem.ToString();
            temp = temp.Substring(0, 4);
            SqlCommand command;
            SqlDataReader dataReader;
            String query1 = "";
            query1 = "Select * from HoaDon_Sach where MaHD = @ma";
            command = new SqlCommand(query1, cnn);
            command.Parameters.AddWithValue("ma", temp);
            dataReader = command.ExecuteReader();
            lstChitiet.Items.Add("Mã HD - Mã Sách - Số lượng");
            while (dataReader.Read())
            {
                String content = dataReader.GetValue(0).ToString() + " - " +
                    dataReader.GetValue(1).ToString() + " - " +
                    dataReader.GetValue(2).ToString();
                lstChitiet.Items.Add(content);
            }
            dataReader.Close();
            command.Dispose();
        }
    }
}
